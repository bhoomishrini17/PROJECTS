<html>

<head>
    <title>Online Examination System</title>
</head>
<?php

if (isset($_POST['studsu'])) {
    session_start();
    if (isset($_POST['name1']) && isset($_POST['usn1']) && isset($_POST['mail1']) && isset($_POST['phno1']) && isset($_POST['dept1']) && isset($_POST['dob1']) && isset($_POST['gender1']) && isset($_POST['password1']) && isset($_POST['cpassword1'])) {
        require_once 'sql.php';
        $conn = mysqli_connect($host, $user, $ps, $project);       if (!$conn) {
            echo "<script>alert(\"Database error retry after some time !\")</script>";
        }
        $name1 =  $_POST['name1'];
        $usn1 = $_POST['usn1'];
        $mail1 =$_POST['mail1'];
        $phno1 = $_POST['phno1'];
        $dept1 =  $_POST['dept1'];
        $dob1 = $_POST['dob1'];
        $gender1 = $_POST['gender1'];
        $password1 = $_POST['password1'];
        $cpassword1 =  $_POST['cpassword1'];
        if ($password1 == $cpassword1) {
            $sql = "insert into student (usn,name,mail,phno,dept,gender,DOB,pw) values('$usn1','$name1','$mail1','$phno1','$dept1','$gender1','$dob1','$password1')";
            if (mysqli_query($conn, $sql)) {
                echo "<script>
                alert('successful!');
                window.location.replace(\"index.php\");</script>";
                session_destroy();
            } else {
                echo "<script>
                alert('Data enter by you alreay exist in Database please Sign In');
                window.location.replace(\"index.php\");</script>";
                session_destroy();
            }
        } else {
            echo "<script>
                alert(' Password should be same');
                window.location.replace(\"singup.php\");</script>";
            session_destroy();
        }
    }
}

if (isset($_POST['staffsu'])) {
    session_start();
    if (isset($_POST['name2']) && isset($_POST['staffid']) && isset($_POST['mail2']) && isset($_POST['phno2']) && isset($_POST['dept2']) && isset($_POST['dob2']) && isset($_POST['gender2']) && isset($_POST['password2']) && isset($_POST['cpassword2'])) {
require 'sql.php';
        $conn = mysqli_connect($host, $user, $ps, $project);        if (!$conn) {
            echo "<script>alert(\"Database error retry after some time !\")</script>";
        }
        $name2 = $_POST['name2'];
        $usn2 = $_POST['staffid'];
        $mail2 = $_POST['mail2'];
        $phno2 = $_POST['phno2'];
        $dept2 =$_POST['dept2'];
        $dob2 = $_POST['dob2'];
        $gender2 =$_POST['gender2'];
        $password2 = $_POST['password2'];
        $cpassword2 = $_POST['cpassword2'];
       
        if ($password2 == $cpassword2) {
            $sql = "insert into staff (staffid,name,mail,phno,dept,gender,DOB,pw) values('$usn2','$name2','$mail2','$phno2','$dept2','$gender2','$dob2','$password2')";
            if (mysqli_query($conn, $sql)) {
                echo "<script>
                alert('successful!');
                window.location.replace(\"index.php\");</script>";
                session_destroy();
            } else {
                echo "<script>
                alert('Data enter by you alreay exist in Database please Sign In');
                window.location.replace(\"index.php\");</script>";
                session_destroy();
            }
        } else {
            echo "<script>
                alert(' Password should be same');
                window.location.replace(\"signup.php\");</script>";
            session_destroy();
        }
    }
}
?>
<style>
    button {
        height: 4vw;
        width: 40vw;
        margin: 0px;
        font-family: 'Courier New', Courier, monospace;
        font-weight: bolder;
        outline: none;
        border: none;
    }

    
    .stud,
    .staff {
        display: none;
    }

 
    

    input,
    .selc {
        width: 30vw !important;
        outline: none;
        height: 3vw;
        border: 2px solid black;
        padding: 1vw;
    }

    .gen {
        width: 2vw !important;
    }

    form>button {
        width: 10vw;
        height: 2vw;
    }
    a{
        color: #042A38;
        margin: 2vw;
    }
    .su {
        width: 10vw !important;
        background-color: #fff;
        margin-bottom: 1vw;
    }

    
    
</style

         <center>
            <h1 >ONLINE EXAMINATION SYSTEM</h1>
        </center>
        
            <center> <button onclick="stud()">STUDENT</button><button onclick="staff()">STAFF</button></center>
        </div>
        <div class="stud" id="stud">
            <center>

                <form name="student" method="POST" ><br>
                    <h1 >Sign-Up as Student</h1><br><br>
                    <label for="name1">NAME</label><br>
                    <input type="text" name="name1" required><br><br>
                    <label for="usn">USN</label><br>
                    <input type="text" name="usn1" required><br><Br>
                    <label for="mail1">Email</label><br>
                    <input type="email" name="mail1" required><br><Br>
                    <label for="phno1">Ph No.</label><br>
                    <input type="tel" name="phno1" required><br><Br>
                    <label for="dept1">Department</label><br>
                    <input type="text" name="dept1"  required>
                    <br><br>
                    <label for="dob1">DOB</label><br>
                    <input type="date" name="dob1" required><br><Br>
                    <label for="gender1">Gender</label><br>
                    <input type="radio" name="gender1" value="M"  class="gen" required style="height: 1vw !important;">MALE
                    <input type="radio" name="gender1" value="F"  class="gen" required style="height: 1vw !important;" >FEMALE<br><Br>
                    <label for="password1">Password</label><br>
                    <input type="password" name="password1" required><br><Br>
                    <label for="cpassword1">Confirm Password</label><br>
                    <input type="password" name="cpassword1" required><br><Br>
                    <input type="submit" class="su" name="studsu" value="Sign-Up as Student">
                </form>

            </center>
        </div>
        <div class="staff" id="staff">
            <center>

                <form name="staffSIGNUP" method="POST" ><br>

                    <h1 class="formname">Sign-Up as Staff</h1><br><br><label for="name">NAME</label><br>
                    <input type="text" name="name2" required><br><br>
                    <label for="staffid">Staff Id</label><br>
                    <input type="text" name="staffid" required><br><Br>
                    <label for="mail2">Email</label><br>
                    <input type="email" name="mail2" required><br><Br>
                    <label for="phno2">Ph No.</label><br>
                    <input type="tel" name="phno2" required><br><Br>
                    <label for="dept2">Department</label><br>
                    <input type="text" name="dept2"  required>
                    <br><br>
					<label for="dob2">DOB</label><br>
                    <input type="date" name="dob2" required><br><Br>
                    <label for="gender2">Gender</label><br>
                    <input type="radio" name="gender2" value="M" class="gen" required style="height: 1vw !important;">MALE
                    <input type="radio" name="gender2" value="F" class="gen" required style="height: 1vw !important;">FEMALE<br><Br>
                    <label for="password2">Password</label><br>
                    <input type="password" name="password2" required><br><Br>
                    <label for="cpassword2">Confirm Password</label><br>
                    <input type="password" name="cpassword2" required><br><Br>
                    <input type="submit" name="staffsu" class="su" value="Sign-Up as Staff">
                </form>
            </center>
        </div>
        <center><a href="index.php" >Cancel</a></center>
    </div>

</body>
<script>
    function stud() {
        document.getElementById('stud').style = "display:initial";
        document.getElementById('staff').style = "display:hidden";
    }

    function staff() {
        document.getElementById('stud').style = "display:hidden";
        document.getElementById('staff').style = "display:initial";
    }
</script>


</html>
