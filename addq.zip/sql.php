<?php 
$host='localhost';
$user='root';
$project='project';
$ps='';
?>
