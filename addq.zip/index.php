<?php session_start(); ?>
<html>

<head>
    <title>Online Examination System</title>
     
</head><?php
        if (isset($_POST['login'])) {
            if (isset($_POST['usertype']) && isset($_POST['username']) && isset($_POST['pass'])) {        require_once 'sql.php';
                $conn = mysqli_connect($host, $user, $ps, $project);if (!$conn) {
                    echo "<script>alert(\"Database error retry after some time !\")</script>";
                }
				$type = mysqli_real_escape_string($conn, $_POST['usertype']);
                $username = mysqli_real_escape_string($conn, $_POST['username']);
                $password = mysqli_real_escape_string($conn, $_POST['pass']);
                $sql = "select * from " . $type . " where mail='{$username}'";
                $res =   mysqli_query($conn, $sql);
                if ($res == true) {
                    global $dbmail, $dbpw;
                    while ($row = mysqli_fetch_array($res)) {
                        $dbpw = $row['pw'];
                        $dbmail = $row['mail'];
                        $_SESSION["name"] = $row['name'];
                        $_SESSION["type"] = $type;
                        $_SESSION["username"] = $dbmail;
                    }
                    if ($dbpw === $password) {
                        if ($type === 'student') {
                            header("Location:homestud.php");
                        } elseif ($type === 'staff') {
                            header("Location:homestaff.php");
                        }
                    } elseif ($dbpw !== $password && $dbmail === $username) {
                        echo "<script>alert('password is wrong');</script>";
                    } elseif ($dbpw !== $password && $dbmail !== $username) {
                        echo "<script>alert('username name not found sing up');</script>";
                    }
                }
            }
        }
        ?>

        <center>
            <h1>ONLINE EXAMINATION SYSTEM</h1>
        
           
                <form method="POST">
                    
                        <input type="radio" name="usertype" value="student" required>STUDENT
                        <input type="radio" name="usertype" value="staff" required>STAFF
                        <br><br>
                    

                        <label for="username">Username</label><br><br>
                        <input type="email" name="username"  required>
                        <br><br>
                        <label for="password" >Password</label><br><br>
                        <input type="password" name="pass"   required>
                        <br><br>
                        <input name="login" class="sub" type="submit" value="Login" ><br>

                </form><br>
                New user! <a href="signup.php">SIGN UP</a>
            
    
    </center>
    

</html>